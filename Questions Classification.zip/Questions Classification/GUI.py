import datetime

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
import pymysql as MySQLdb
from PyQt5.uic import loadUiType


predict, _ = loadUiType('predict.ui')
prediction, _ = loadUiType('prediction.ui')

class Predict(QMainWindow, predict):
    def __init__(self):
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.pushButton.clicked.connect(self.call_prediction)

    def call_prediction(self):
        text_data = self.textEdit.toPlainText()
        self.window = MainApp()
        self.close()
        self.window.show()

class MainApp(QMainWindow, prediction):
    def __init__(self):
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.getQuestion(self)

    def getQuestion(self):
        self.pushButton.clicked.connect(self.Show_Prediction)

    def Show_Prediction(self):
        pass

        # print(text_data)
        # self.textBrowser.setText(accuracy_NB_CV)
        # self.textBrowser_2.setText(accuracy_NB_Tf_IDF)
        #
        #
        # self.textBrowser_4.setText(accuracy_LR_CV)
        # self.textBrowser_3.setText(accuracy_LR_TF_IDF)
        #
        #
        # self.textBrowser_6.setText(accuracy_SVM_CV)
        # self.textBrowser_5.setText(accuracy_SVM_TF_IDF)


def main():
        app = QApplication(sys.argv)
        window = Predict()
        window.show()
        app.exec_()
if __name__ == '__main__':
        main()
